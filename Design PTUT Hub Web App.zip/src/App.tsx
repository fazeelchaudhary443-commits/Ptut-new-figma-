import { useEffect, useMemo, useState } from "react";

type Screen =
  | "dashboard"
  | "timetable"
  | "tasks"
  | "exams"
  | "announcements"
  | "profile"
  | "settings"
  | "admin"
  | "students"
  | "academic"
  | "manage-timetable"
  | "manage-announcements"
  | "cr"
  | "states";

type IconName =
  | "home" | "calendar" | "check" | "exam" | "bell" | "user" | "settings"
  | "search" | "plus" | "arrow" | "clock" | "room" | "book" | "spark"
  | "menu" | "close" | "more" | "sun" | "chart" | "people" | "building"
  | "edit" | "trash" | "chevron" | "shield" | "wifi" | "alert" | "mail";

const paths: Record<IconName, React.ReactNode> = {
  home: <><path d="M3 10.8 12 3l9 7.8"/><path d="M5 9.5V21h14V9.5M9 21v-7h6v7"/></>,
  calendar: <><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M16 3v4M8 3v4M3 10h18"/></>,
  check: <path d="m5 12 4 4L19 6"/>,
  exam: <><path d="M6 3h12a2 2 0 0 1 2 2v16H4V5a2 2 0 0 1 2-2Z"/><path d="M8 8h8M8 12h8M8 16h5"/></>,
  bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></>,
  user: <><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>,
  settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.8 1.8 0 0 0 .4 2l.1.1-2.8 2.8-.1-.1a1.8 1.8 0 0 0-2-.4 1.8 1.8 0 0 0-1.1 1.7v.2h-4v-.2A1.8 1.8 0 0 0 8.8 19a1.8 1.8 0 0 0-2 .4l-.1.1-2.8-2.8.1-.1a1.8 1.8 0 0 0 .4-2A1.8 1.8 0 0 0 2.7 13h-.2V9h.2a1.8 1.8 0 0 0 1.7-1.1 1.8 1.8 0 0 0-.4-2l-.1-.1L6.7 3l.1.1a1.8 1.8 0 0 0 2 .4A1.8 1.8 0 0 0 10 1.8v-.2h4v.2a1.8 1.8 0 0 0 1.1 1.7 1.8 1.8 0 0 0 2-.4l.1-.1L20 5.8l-.1.1a1.8 1.8 0 0 0-.4 2A1.8 1.8 0 0 0 21.2 9h.2v4h-.2a1.8 1.8 0 0 0-1.8 2Z"/></>,
  search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
  plus: <path d="M12 5v14M5 12h14"/>,
  arrow: <path d="m5 12 14 0m-6-6 6 6-6 6"/>,
  clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
  room: <><path d="M4 21V5l12-2v18M16 8h4v13M9 12h2"/></>,
  book: <><path d="M4 5a3 3 0 0 1 3-2h5v18H7a3 3 0 0 0-3 2Z"/><path d="M20 5a3 3 0 0 0-3-2h-5v18h5a3 3 0 0 1 3 2Z"/></>,
  spark: <path d="m12 3 1.3 4.2L17 9l-3.7 1.8L12 15l-1.3-4.2L7 9l3.7-1.8ZM5 15l.8 2.2L8 18l-2.2.8L5 21l-.8-2.2L2 18l2.2-.8Z"/>,
  menu: <path d="M4 7h16M4 12h16M4 17h16"/>,
  close: <path d="m6 6 12 12M18 6 6 18"/>,
  more: <><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></>,
  sun: <><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></>,
  chart: <><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></>,
  people: <><circle cx="9" cy="8" r="3"/><path d="M3 20v-2a6 6 0 0 1 12 0v2"/><circle cx="17" cy="9" r="2"/><path d="M16 14a5 5 0 0 1 5 5v1"/></>,
  building: <><path d="M3 21h18M5 21V7l7-4 7 4v14M9 10h2M14 10h2M9 14h2M14 14h2"/></>,
  edit: <><path d="m4 20 4.5-1L20 7.5 16.5 4 5 15.5Z"/><path d="m14.5 6 3.5 3.5"/></>,
  trash: <><path d="M4 7h16M9 7V4h6v3M7 7l1 14h8l1-14"/></>,
  chevron: <path d="m9 18 6-6-6-6"/>,
  shield: <><path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"/><path d="m9 12 2 2 4-4"/></>,
  wifi: <><path d="M4 9a13 13 0 0 1 16 0M7 13a8 8 0 0 1 10 0M10 17a3 3 0 0 1 4 0"/><circle cx="12" cy="20" r=".5"/></>,
  alert: <><path d="M12 3 2 21h20Z"/><path d="M12 9v5M12 18h.01"/></>,
  mail: <><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></>,
};

function Icon({ name, size = 19 }: { name: IconName; size?: number }) {
  return <svg className="icon" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

function Button({ children, variant = "primary", icon, onClick, className = "", type = "button" }: {
  children?: React.ReactNode; variant?: "primary" | "secondary" | "ghost" | "danger" | "icon";
  icon?: IconName; onClick?: () => void; className?: string; type?: "button" | "submit";
}) {
  return <button type={type} className={`btn btn-${variant} ${className}`} onClick={onClick}>{icon && <Icon name={icon}/>} {children}</button>;
}

function Logo({ compact = false }: { compact?: boolean }) {
  return <div className="logo"><div className="logo-mark"><span>P</span></div>{!compact && <div><strong>PTUT Hub</strong><small>Student workspace</small></div>}</div>;
}

function Tag({ children, tone = "green" }: { children: React.ReactNode; tone?: "green" | "red" | "blue" | "gray" | "amber" }) {
  return <span className={`tag tag-${tone}`}>{children}</span>;
}

function Avatar({ name = "FM", small = false }: { name?: string; small?: boolean }) {
  return <div className={`avatar ${small ? "avatar-small" : ""}`}>{name}</div>;
}

const navItems: { id: Screen; label: string; icon: IconName }[] = [
  { id: "dashboard", label: "Home", icon: "home" },
  { id: "timetable", label: "Timetable", icon: "calendar" },
  { id: "tasks", label: "Tasks", icon: "check" },
  { id: "exams", label: "Exams", icon: "exam" },
  { id: "announcements", label: "Announcements", icon: "bell" },
];

const classItems = [
  { time: "08:30", title: "Applied Physics", room: "Room 204", state: "done", meta: "Dr. Ali Raza" },
  { time: "10:00", title: "Programming Fundamentals", room: "Lab 2", state: "current", meta: "Dr. Ayesha Khan" },
  { time: "11:30", title: "Digital Logic Design", room: "Room 301", state: "next", meta: "Engr. Usman Tariq" },
  { time: "13:00", title: "Lunch break", room: "Student café", state: "break", meta: "45 minutes" },
  { time: "14:00", title: "Calculus & Analytical Geometry", room: "Room 101", state: "next", meta: "Ms. Sana Ahmed" },
];

function Landing({ onStart }: { onStart: () => void }) {
  const [mobileMenu, setMobileMenu] = useState(false);
  return <div className="landing">
    <header className="landing-nav">
      <Logo/>
      <div className={`landing-links ${mobileMenu ? "open" : ""}`}>
        <button onClick={() => document.querySelector("#features")?.scrollIntoView({ behavior: "smooth" })}>Features</button>
        <button onClick={() => document.querySelector("#productivity")?.scrollIntoView({ behavior: "smooth" })}>Productivity</button>
        <button onClick={() => document.querySelector("#impact")?.scrollIntoView({ behavior: "smooth" })}>Impact</button>
      </div>
      <div className="landing-actions"><Button variant="ghost" onClick={onStart}>Sign in</Button><Button onClick={onStart}>Get started <Icon name="arrow"/></Button></div>
      <Button variant="icon" icon={mobileMenu ? "close" : "menu"} className="mobile-menu" onClick={() => setMobileMenu(!mobileMenu)}/>
    </header>

    <main>
      <section className="hero">
        <div className="hero-orb orb-one"/>
        <div className="hero-orb orb-two"/>
        <div className="hero-copy">
          <Tag tone="green"><Icon name="spark" size={15}/> Built for PTUT students</Tag>
          <div className="display-title">Your PTUT Life,<br/><em>Organized.</em></div>
          <p>Timetable, tasks, exams, announcements, and your academic life — thoughtfully brought together in one focused workspace.</p>
          <div className="hero-actions"><Button onClick={onStart}>Get started <Icon name="arrow"/></Button><Button variant="secondary" onClick={() => document.querySelector("#features")?.scrollIntoView({ behavior: "smooth" })}>Explore PTUT Hub</Button></div>
          <div className="trust-row"><span className="avatar-stack"><Avatar name="FA" small/><Avatar name="AM" small/><Avatar name="SK" small/></span><span>Designed with students from Lahore</span></div>
        </div>
        <div className="hero-visual">
          <div className="browser">
            <div className="browser-bar"><div><i/><i/><i/></div><span>app.ptuthub.pk</span><Icon name="shield" size={16}/></div>
            <div className="browser-app">
              <div className="mini-sidebar"><Logo compact/><Icon name="home"/><Icon name="calendar"/><Icon name="check"/><Icon name="exam"/></div>
              <div className="mini-main">
                <div className="mini-top"><div><small>WEDNESDAY, 14 MAY</small><strong>Good morning, Fazeel</strong></div><Avatar small/></div>
                <div className="mini-grid">
                  <div className="mini-current"><Tag>HAPPENING NOW</Tag><strong>Programming<br/>Fundamentals</strong><span>Lab 2 · 10:00–11:30</span><div className="progress"><i style={{ width: "64%" }}/></div></div>
                  <div className="mini-next"><small>UP NEXT</small><Icon name="book"/><strong>Digital Logic</strong><span>Starts in 24 min</span></div>
                </div>
                <div className="mini-schedule"><small>TODAY'S SCHEDULE</small>{classItems.slice(0, 3).map((item) => <div key={item.time}><b>{item.time}</b><i className={item.state}/><span>{item.title}<small>{item.room}</small></span></div>)}</div>
              </div>
            </div>
          </div>
          <div className="float-card float-exam"><div className="float-icon red"><Icon name="exam"/></div><div><small>UPCOMING EXAM</small><strong>Data Structures</strong><span>3 days remaining</span></div></div>
          <div className="float-card float-task"><div className="ring">80<small>%</small></div><div><small>WEEKLY PROGRESS</small><strong>8 of 10 tasks</strong><span>You're on track</span></div></div>
        </div>
      </section>

      <section className="logo-strip"><span>Everything you need to thrive at</span><strong>Punjab Tianjin University of Technology</strong><span>Lahore, Pakistan</span></section>

      <section className="section" id="features">
        <div className="section-heading"><Tag tone="red">ONE FOCUSED WORKSPACE</Tag><div className="section-title">Less juggling. More learning.</div><p>Built around the rhythm of real student life — quick when you need it, quiet when you don't.</p></div>
        <div className="feature-grid">
          <article className="feature-card feature-large"><div className="feature-icon"><Icon name="calendar"/></div><div className="feature-title">A timetable that keeps up</div><p>See what's happening now, what's next, and every room change — at a glance.</p><div className="week-preview">{["MON","TUE","WED","THU","FRI"].map((day, i) => <div className={i === 2 ? "active" : ""} key={day}><b>{day}</b><span>{12+i}</span></div>)}</div></article>
          <article className="feature-card dark-card"><div className="feature-icon"><Icon name="check"/></div><div className="feature-title">Tasks with momentum</div><p>Capture assignments and build a clear plan before deadlines become stressful.</p><div className="task-preview"><span><i className="checked"><Icon name="check" size={13}/></i> Physics lab report</span><span><i/> Programming assignment</span><span><i/> Review calculus notes</span></div></article>
          <article className="feature-card"><div className="feature-icon red-soft"><Icon name="bell"/></div><div className="feature-title">Never miss an update</div><p>Important notices from your university, department, and section in one calm feed.</p><div className="announcement-preview"><Avatar name="CS" small/><div><b>CS Department</b><span>Lab schedule updated for Friday</span></div><i/></div></article>
        </div>
      </section>

      <section className="productivity-section" id="productivity">
        <div className="productivity-copy"><Tag tone="blue">MADE FOR MOMENTUM</Tag><div className="section-title">Know exactly what deserves your attention.</div><p>Your day, intelligently prioritized. PTUT Hub surfaces current classes, approaching deadlines, and important notices without the noise.</p>
          <ul><li><Icon name="check"/> Smart daily overview</li><li><Icon name="check"/> Exam preparation tracking</li><li><Icon name="check"/> Section-aware announcements</li></ul><Button onClick={onStart}>See your dashboard <Icon name="arrow"/></Button>
        </div>
        <div className="phone-stage">
          <div className="phone"><div className="phone-top"><span>9:41</span><i/></div><div className="phone-content"><div className="mobile-greet"><small>GOOD MORNING</small><strong>Fazeel</strong></div><div className="phone-current"><Tag>NOW</Tag><strong>Programming Fundamentals</strong><span>Lab 2 · until 11:30 AM</span><div className="progress"><i style={{ width: "64%" }}/></div></div><small className="label">YOUR DAY</small>{classItems.slice(1,4).map(x=><div className="phone-event" key={x.time}><b>{x.time}</b><i/><span>{x.title}<small>{x.room}</small></span></div>)}<div className="phone-nav">{["home","calendar","check","exam","more"].map((x,i)=><Icon name={x as IconName} key={x}/>)}</div></div></div>
          <div className="phone-note note-one"><Icon name="bell"/><span><b>Room changed</b>Digital Logic · Lab 3</span></div>
          <div className="phone-note note-two"><Icon name="check"/><span><b>Nice work</b>Assignment completed</span></div>
        </div>
      </section>

      <section className="impact" id="impact"><div><small>BUILT FOR OUR CAMPUS</small><div className="impact-title">One connected student experience.</div></div><div className="stats"><span><b>6</b>Academic departments</span><span><b>24/7</b>Always accessible</span><span><b>1</b>Focused workspace</span></div></section>
      <section className="final-cta"><div className="cta-pattern"/><Tag>YOUR SEMESTER, SIMPLIFIED</Tag><div className="section-title">Ready to take control of your day?</div><p>Join the new student workspace built specifically for PTUT.</p><Button onClick={onStart}>Get started free <Icon name="arrow"/></Button></section>
    </main>
    <footer><Logo/><span>Built for PTUT students in Lahore.</span><div><button>Privacy</button><button>Help center</button><button>Contact</button></div></footer>
  </div>;
}

function Auth({ onComplete, onBack }: { onComplete: () => void; onBack: () => void }) {
  const [mode, setMode] = useState<"login"|"signup"|"forgot"|"verify">("login");
  const [loading, setLoading] = useState(false);
  const submit = (e: React.FormEvent) => { e.preventDefault(); setLoading(true); setTimeout(() => { setLoading(false); mode === "forgot" ? setMode("verify") : onComplete(); }, 700); };
  return <div className="auth-page">
    <div className="auth-brand">
      <button className="back-link" onClick={onBack}><Icon name="arrow"/> Back to home</button>
      <Logo/>
      <div className="auth-quote"><Tag>STUDENT LIFE, IN SYNC</Tag><div>“PTUT Hub helps me focus on learning instead of tracking five different groups.”</div><span><Avatar name="MA" small/><b>Maha Ali</b> · Computer Science, 4th semester</span></div>
      <div className="auth-grid"/>
    </div>
    <div className="auth-form-wrap">
      <form className="auth-card" onSubmit={submit}>
        {mode === "verify" ? <><div className="success-icon"><Icon name="mail" size={28}/></div><div className="form-title">Check your inbox</div><p>We sent a password reset link to <b>fazeel@ptut.edu.pk</b>. It expires in 15 minutes.</p><Button className="full" onClick={() => setMode("login")}>Back to sign in</Button></> : <>
          <div className="form-eyebrow">{mode === "signup" ? "CREATE YOUR ACCOUNT" : mode === "forgot" ? "RESET PASSWORD" : "WELCOME BACK"}</div>
          <div className="form-title">{mode === "signup" ? "Start organizing your PTUT life." : mode === "forgot" ? "Let's get you back in." : "Sign in to PTUT Hub"}</div>
          <p>{mode === "forgot" ? "Enter your university email and we'll send you a secure reset link." : "Use your university account to continue."}</p>
          {mode === "signup" && <label>Full name<div className="input-wrap"><Icon name="user"/><input required placeholder="e.g. Fazeel Mahmood"/></div></label>}
          <label>University email<div className="input-wrap"><Icon name="mail"/><input type="email" required placeholder="name@ptut.edu.pk"/></div></label>
          {mode !== "forgot" && <label>Password<div className="input-wrap"><Icon name="shield"/><input type="password" required placeholder="At least 8 characters"/></div></label>}
          {mode === "signup" && <div className="strength"><i/><i/><i/><i/><span>Use 8+ characters with a number</span></div>}
          {mode === "login" && <div className="form-row"><label className="checkbox"><input type="checkbox"/> Remember me</label><button type="button" className="text-button" onClick={() => setMode("forgot")}>Forgot password?</button></div>}
          <Button type="submit" className="full">{loading ? <span className="loader"/> : mode === "signup" ? "Create account" : mode === "forgot" ? "Send reset link" : "Sign in"}{!loading && <Icon name="arrow"/>}</Button>
          <div className="auth-switch">{mode === "signup" ? "Already have an account?" : "New to PTUT Hub?"} <button type="button" onClick={() => setMode(mode === "signup" ? "login" : "signup")}>{mode === "signup" ? "Sign in" : "Create account"}</button></div>
        </>}
      </form>
      <span className="auth-legal">By continuing, you agree to our Terms and Privacy Policy.</span>
    </div>
  </div>;
}

function Onboarding({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState(0);
  const steps = ["Personal", "Department", "Program", "Semester", "Section", "Done"];
  const data = [
    { title: "Let's get to know you", text: "This helps personalize your PTUT Hub experience.", label: "What should we call you?", options: ["Fazeel Mahmood"] },
    { title: "Choose your department", text: "We'll match your academic structure and updates.", label: "Department", options: ["Electrical Engineering Technology","Computer Science","Automotive Engineering Technology"] },
    { title: "Select your program", text: "Your classes and exams will be tailored to your program.", label: "Program", options: ["BS Computer Science","BS Information Technology","BS Software Engineering"] },
    { title: "Which semester are you in?", text: "You can update this later from your profile.", label: "Current semester", options: ["Semester 4","Semester 3","Semester 5"] },
    { title: "Finally, select your section", text: "Section-specific timetables and notices will appear automatically.", label: "Section", options: ["Section A","Section B","Section C"] },
  ];
  const current = data[Math.min(step, 4)];
  return <div className="onboarding"><header><Logo/><span>Step {step + 1} of 6</span></header><div className="stepper">{steps.map((s,i)=><div className={i <= step ? "active" : ""} key={s}><i>{i < step ? <Icon name="check" size={13}/> : i+1}</i><span>{s}</span></div>)}</div>
    <div className="onboarding-card">{step === 5 ? <><div className="success-icon"><Icon name="check" size={28}/></div><div className="form-title">You're all set, Fazeel.</div><p>Your personalized PTUT workspace is ready. We've matched your timetable, section, and academic updates.</p><div className="confirm-box"><span><b>BS Computer Science</b>Computer Science Department</span><Tag>Semester 4 · Section A</Tag></div><Button className="full" onClick={onComplete}>Open my dashboard <Icon name="arrow"/></Button></> : <>
      <div className="form-eyebrow">PERSONALIZE YOUR HUB</div><div className="form-title">{current.title}</div><p>{current.text}</p><label>{current.label}</label>
      <div className="option-list">{current.options.map((opt,i)=><button className={i===0 ? "selected" : ""} key={opt}><span><i>{i===0 && <Icon name="check" size={14}/>}</i>{opt}</span><Icon name="chevron"/></button>)}</div>
      <div className="onboarding-actions"><Button variant="ghost" onClick={() => setStep(Math.max(0, step-1))}>Back</Button><Button onClick={() => setStep(step+1)}>Continue <Icon name="arrow"/></Button></div>
    </>}</div>
  </div>;
}

function Header({ title, onSearch, onNotify }: { title?: string; onSearch: () => void; onNotify: () => void }) {
  return <header className="app-header"><div className="mobile-logo"><Logo compact/></div><div className="header-title">{title}</div><button className="search-trigger" onClick={onSearch}><Icon name="search"/><span>Search anything...</span><kbd>⌘ K</kbd></button><div className="header-actions"><Button variant="secondary" icon="plus" className="quick">Quick add</Button><Button variant="icon" icon="bell" className="notification-button" onClick={onNotify}/><button className="profile-trigger"><Avatar name="FM" small/><span><b>Fazeel</b><small>Semester 4 · A</small></span><Icon name="chevron" size={15}/></button></div></header>;
}

function Sidebar({ screen, setScreen, role, setRole }: { screen: Screen; setScreen: (s: Screen) => void; role: "student"|"admin"|"cr"; setRole: (r:"student"|"admin"|"cr") => void }) {
  const adminNav: {id:Screen;label:string;icon:IconName}[] = [
    {id:"admin",label:"Overview",icon:"chart"},{id:"students",label:"Students",icon:"people"},{id:"academic",label:"Academic structure",icon:"building"},{id:"manage-timetable",label:"Timetables",icon:"calendar"},{id:"manage-announcements",label:"Announcements",icon:"bell"}
  ];
  const list = role === "admin" ? adminNav : role === "cr" ? [{id:"cr" as Screen,label:"CR Overview",icon:"shield" as IconName},...navItems.slice(1)] : navItems;
  return <aside className="sidebar"><div className="sidebar-top"><Logo/><button className="collapse"><Icon name="menu"/></button></div><div className="workspace-label">{role === "admin" ? "ADMIN CONSOLE" : role === "cr" ? "SECTION A · CR" : "MY WORKSPACE"}</div><nav>{list.map(item=><button className={screen===item.id ? "active" : ""} key={item.id} onClick={()=>setScreen(item.id)}><Icon name={item.icon}/><span>{item.label}</span>{item.id==="announcements"&&<i>3</i>}</button>)}</nav>
    <div className="sidebar-bottom"><button onClick={()=>setScreen("profile")} className={screen==="profile"?"active":""}><Icon name="user"/>Profile</button><button onClick={()=>setScreen("settings")} className={screen==="settings"?"active":""}><Icon name="settings"/>Settings</button><div className="role-switch"><small>VIEW AS</small><select value={role} onChange={e=>{const r=e.target.value as typeof role; setRole(r); setScreen(r==="admin"?"admin":r==="cr"?"cr":"dashboard")}}><option value="student">Student</option><option value="cr">Class representative</option><option value="admin">Administrator</option></select></div><div className="sidebar-profile"><Avatar name="FM" small/><span><b>Fazeel Mahmood</b><small>fazeel@ptut.edu.pk</small></span><Icon name="more"/></div></div>
  </aside>;
}

function PageTitle({ eyebrow, title, text, action }: { eyebrow?: string; title: string; text?: string; action?: React.ReactNode }) {
  return <div className="page-title"><div>{eyebrow&&<small>{eyebrow}</small>}<div className="title">{title}</div>{text&&<p>{text}</p>}</div>{action}</div>;
}

function Dashboard({ setScreen }: { setScreen: (s:Screen)=>void }) {
  return <div className="page">
    <PageTitle eyebrow="WEDNESDAY, 14 MAY" title="Good morning, Fazeel." text="Semester 4 · Section A · BS Computer Science" action={<div className="weather"><Icon name="sun"/><span><b>31°C</b>Lahore</span></div>}/>
    <div className="now-grid">
      <article className="current-class"><div className="card-top"><Tag>CURRENT CLASS</Tag><span><i/> Currently happening</span></div><div className="current-body"><div><div className="subject">Programming Fundamentals</div><span>Dr. Ayesha Khan</span></div><div className="class-meta"><span><Icon name="room"/>Lab 2</span><span><Icon name="clock"/>10:00 AM – 11:30 AM</span></div></div><div className="class-progress"><div><span>Class progress</span><b>58 min remaining</b></div><div className="progress"><i style={{width:"36%"}}/></div><div className="progress-label"><span>10:00</span><span>11:30</span></div></div><button className="card-link">View class details <Icon name="arrow"/></button></article>
      <article className="next-class"><div className="card-top"><Tag tone="blue">UP NEXT</Tag><Icon name="more"/></div><div className="countdown"><span>Starts in</span><b>24<small>min</small></b></div><div className="next-subject"><div className="subject-dot blue"/><div><b>Digital Logic Design</b><span>Engr. Usman Tariq</span></div></div><div className="next-meta"><span><Icon name="clock"/>11:30 AM</span><span><Icon name="room"/>Room 301</span></div></article>
    </div>
    <div className="content-grid">
      <section className="card schedule-card"><div className="card-heading"><div><b>Today's schedule</b><span>5 events · 2 remaining</span></div><button onClick={()=>setScreen("timetable")}>Full timetable <Icon name="arrow"/></button></div><div className="timeline">{classItems.map(item=><div className={`timeline-item ${item.state}`} key={item.time}><time>{item.time}</time><i/><div><b>{item.title}</b><span>{item.meta}</span></div><span className="timeline-room">{item.room}</span>{item.state==="current"&&<Tag>NOW</Tag>}</div>)}</div></section>
      <aside className="dashboard-side"><section className="card"><div className="card-heading"><div><b>Tasks</b><span>3 due soon</span></div><button onClick={()=>setScreen("tasks")}>View all</button></div><div className="compact-tasks"><TaskMini title="Programming assignment" meta="Due tomorrow" tone="red"/><TaskMini title="Physics lab report" meta="Due Friday" tone="amber"/><TaskMini title="Review calculus notes" meta="Due in 4 days" tone="blue"/></div><Button variant="secondary" icon="plus" className="full">Add a task</Button></section>
        <section className="card exam-card"><div className="card-heading"><div><b>Next exam</b><span>Prepare ahead</span></div><Icon name="exam"/></div><Tag tone="red">3 DAYS LEFT</Tag><div className="exam-title">Data Structures Midterm</div><span>Saturday, 17 May · 9:00 AM</span><div className="prep"><div><span>Preparation</span><b>65%</b></div><div className="progress"><i style={{width:"65%"}}/></div></div></section>
      </aside>
    </div>
  </div>;
}

function TaskMini({title,meta,tone}:{title:string;meta:string;tone:"red"|"amber"|"blue"}) { return <div className="task-mini"><button><Icon name="check" size={14}/></button><div><b>{title}</b><span>{meta}</span></div><i className={tone}/></div> }

function Timetable() {
  const [view,setView]=useState<"week"|"day">("week");
  const [selected,setSelected]=useState<string|null>(null);
  const subjects=[
    {day:0,start:1,span:2,title:"Applied Physics",room:"204",tone:"blue"},
    {day:1,start:2,span:2,title:"Calculus",room:"101",tone:"purple"},
    {day:2,start:2,span:2,title:"Programming Fundamentals",room:"Lab 2",tone:"green"},
    {day:3,start:1,span:2,title:"Digital Logic",room:"301",tone:"orange"},
    {day:4,start:3,span:2,title:"Data Structures",room:"Lab 3",tone:"red"},
    {day:0,start:5,span:2,title:"Calculus",room:"101",tone:"purple"},
    {day:2,start:5,span:2,title:"Applied Physics",room:"204",tone:"blue"},
    {day:4,start:6,span:2,title:"Programming Lab",room:"Lab 2",tone:"green"},
  ];
  return <div className="page"><PageTitle eyebrow="ACADEMIC SCHEDULE" title="Timetable" text="Semester 4 · Section A" action={<div className="segmented"><button className={view==="day"?"active":""} onClick={()=>setView("day")}>Day</button><button className={view==="week"?"active":""} onClick={()=>setView("week")}>Week</button></div>}/>
    <div className="calendar-toolbar"><Button variant="secondary">Today</Button><div><Button variant="icon" icon="chevron"/><b>12 – 16 May, 2025</b><Button variant="icon" icon="chevron"/></div><span><i/> Current time</span></div>
    <section className={`calendar ${view}`}><div className="calendar-head"><span>GMT+5</span>{["MON 12","TUE 13","WED 14","THU 15","FRI 16"].map((x,i)=><b className={i===2?"today":""} key={x}>{x}</b>)}</div><div className="calendar-body"><div className="times">{["8 AM","9 AM","10 AM","11 AM","12 PM","1 PM","2 PM","3 PM","4 PM"].map(x=><span key={x}>{x}</span>)}</div><div className="calendar-grid">{subjects.map((s,i)=><button onClick={()=>setSelected(s.title)} className={`calendar-event ${s.tone}`} style={{gridColumn:s.day+1,gridRow:`${s.start}/span ${s.span}`}} key={i}><b>{s.title}</b><span>{s.room}</span><small>{8+Math.floor(s.start/2)}:{s.start%2?"30":"00"} AM</small></button>)}<div className="now-line"><i/><span>10:42</span></div></div></div></section>
    {selected&&<Modal onClose={()=>setSelected(null)} title="Class details"><div className="detail-hero"><div className="feature-icon"><Icon name="book"/></div><div><Tag>CURRENT CLASS</Tag><div className="detail-title">{selected}</div><span>CS-204 · Semester 4</span></div></div><div className="detail-list"><span><Icon name="user"/><i><small>INSTRUCTOR</small>Dr. Ayesha Khan</i></span><span><Icon name="clock"/><i><small>TIME</small>10:00 AM – 11:30 AM</i></span><span><Icon name="room"/><i><small>LOCATION</small>Computer Lab 2</i></span></div><Button className="full">Add a reminder</Button></Modal>}
  </div>;
}

function Tasks() {
  const [filter,setFilter]=useState("All");
  const [done,setDone]=useState<string[]>(["Physics lab report"]);
  const [add,setAdd]=useState(false);
  const tasks=[
    ["Programming assignment","Programming Fundamentals","Tomorrow","High","80"],
    ["Physics lab report","Applied Physics","Friday","Medium","100"],
    ["Review calculus notes","Calculus","18 May","Low","35"],
    ["Prepare logic circuit","Digital Logic Design","20 May","High","10"],
  ];
  return <div className="page"><PageTitle eyebrow="STAY ON TRACK" title="Tasks" text="4 tasks · 2 due this week" action={<Button icon="plus" onClick={()=>setAdd(true)}>Add task</Button>}/><div className="task-overview"><div><span>Weekly progress</span><b>8 of 10 completed</b><div className="progress"><i style={{width:"80%"}}/></div></div><div className="task-stat"><b>80%</b><span>On track</span></div></div><div className="filter-row">{["All","Today","Upcoming","Completed"].map(x=><button className={filter===x?"active":""} onClick={()=>setFilter(x)} key={x}>{x}<span>{x==="All"?4:x==="Completed"?1:2}</span></button>)}<div className="filter-search"><Icon name="search"/><input placeholder="Search tasks"/></div></div><div className="tasks-list"><div className="list-head"><span>TASK</span><span>SUBJECT</span><span>DUE</span><span>PRIORITY</span><span>PROGRESS</span><span/></div>{tasks.map(task=><div className={`task-row ${done.includes(task[0])?"completed":""}`} key={task[0]}><button className="task-check" onClick={()=>setDone(d=>d.includes(task[0])?d.filter(x=>x!==task[0]):[...d,task[0]])}>{done.includes(task[0])&&<Icon name="check" size={15}/>}</button><div><b>{task[0]}</b><small>Assignment</small></div><span>{task[1]}</span><span>{task[2]}</span><Tag tone={task[3]==="High"?"red":task[3]==="Medium"?"amber":"gray"}>{task[3]}</Tag><div className="row-progress"><div className="progress"><i style={{width:`${task[4]}%`}}/></div><b>{task[4]}%</b></div><Button variant="icon" icon="more"/></div>)}</div>
    {add&&<Modal title="Create a new task" onClose={()=>setAdd(false)}><div className="form-grid"><label className="wide">Task title<input placeholder="e.g. Submit programming assignment"/></label><label>Subject<select><option>Programming Fundamentals</option><option>Applied Physics</option></select></label><label>Category<select><option>Assignment</option><option>Study</option><option>Personal</option></select></label><label>Due date<input type="date"/></label><label>Priority<select><option>High</option><option>Medium</option><option>Low</option></select></label><label className="wide">Notes<textarea placeholder="Add details or a checklist..."/></label></div><div className="modal-actions"><Button variant="ghost" onClick={()=>setAdd(false)}>Cancel</Button><Button onClick={()=>setAdd(false)}>Create task</Button></div></Modal>}
  </div>;
}

function Exams() {
  const exams=[["Data Structures Midterm","3","17 May","09:00 AM","Main Hall","65"],["Digital Logic Quiz","8","22 May","11:30 AM","Room 301","40"],["Applied Physics Final","19","02 June","09:00 AM","Block B","20"]];
  return <div className="page"><PageTitle eyebrow="EXAM READINESS" title="Exams" text="Three upcoming assessments" action={<div className="segmented"><button className="active">List</button><button>Calendar</button></div>}/><section className="exam-countdown"><div><Tag tone="red">NEXT EXAM</Tag><div className="title">Data Structures Midterm</div><p>Saturday, 17 May · 9:00 AM · Main Hall</p><Button variant="secondary">View preparation plan <Icon name="arrow"/></Button></div><div className="count-box"><span><b>03</b>DAYS</span><i>:</i><span><b>18</b>HOURS</span><i>:</i><span><b>42</b>MIN</span></div></section><div className="exam-grid">{exams.map((e,i)=><article className="card exam-list-card" key={e[0]}><div className={`exam-icon ${i===0?"urgent":""}`}><Icon name="exam"/></div><div><Tag tone={i===0?"red":"blue"}>{e[1]} DAYS REMAINING</Tag><div className="exam-title">{e[0]}</div><span>BS Computer Science · Semester 4</span></div><div className="exam-facts"><span><Icon name="calendar"/><i><small>DATE</small>{e[2]}</i></span><span><Icon name="clock"/><i><small>TIME</small>{e[3]}</i></span><span><Icon name="room"/><i><small>ROOM</small>{e[4]}</i></span></div><div className="prep"><div><span>Preparation status</span><b>{e[5]}%</b></div><div className="progress"><i style={{width:`${e[5]}%`}}/></div></div></article>)}</div></div>;
}

function Announcements() {
  const cards=[["Important","Final examination form submission","Office of the Registrar","Forms for Spring 2025 final examinations must be submitted by Friday, 16 May. Late submissions will not be accepted.","2 hours ago"],
  ["Department","Updated computer lab schedule","Department of Computer Science","The lab schedule for sections A and B has been revised for the remainder of this week.","Yesterday"],
  ["University","PTUT Innovation Expo 2025","Student Affairs Office","Student teams are invited to exhibit projects at the annual Innovation Expo in June.","12 May"],
  ["Section","Data Structures makeup class","Class Representative · Section A","A makeup class has been scheduled for Thursday at 2:30 PM in Room 203.","11 May"]];
  return <div className="page"><PageTitle eyebrow="STAY INFORMED" title="Announcements" text="Updates from PTUT and your academic community"/><div className="filter-row announcement-filter">{["All","Important","University","Department","Program","Section"].map((x,i)=><button className={i===0?"active":""} key={x}>{x}</button>)}</div><div className="announcement-layout"><div className="announcement-list">{cards.map((c,i)=><article className={`announcement-card ${i===0?"important":""}`} key={c[1]}><div className="announcement-meta"><Tag tone={i===0?"red":i===3?"green":"blue"}>{c[0]}</Tag><span>{c[4]}</span>{i<2&&<i/>}</div><div className="announcement-title">{c[1]}</div><b>{c[2]}</b><p>{c[3]}</p><button>Read announcement <Icon name="arrow"/></button></article>)}</div><aside className="card announcement-side"><div className="card-heading"><div><b>For you</b><span>Quick summary</span></div><Icon name="spark"/></div><div className="summary-stat"><span><b>3</b>Unread</span><span><b>1</b>Important</span></div><hr/><b>Stay in the loop</b><p>Turn on announcement notifications to receive important PTUT updates instantly.</p><Button variant="secondary" className="full">Notification settings</Button></aside></div></div>;
}

function ProfileSettings({ settings=false }:{settings?:boolean}) {
  const [tab,setTab]=useState(settings?"Appearance":"Personal info");
  const tabs=settings?["Account","Notifications","Appearance","Security","Privacy"]:["Personal info","Academic info","Activity"];
  return <div className="page"><PageTitle eyebrow={settings?"YOUR PREFERENCES":"STUDENT PROFILE"} title={settings?"Settings":"Profile"} text={settings?"Control how PTUT Hub works for you.":"Manage your identity and academic information."}/><div className="settings-layout"><aside className="settings-nav">{tabs.map(x=><button className={tab===x?"active":""} onClick={()=>setTab(x)} key={x}>{x}<Icon name="chevron"/></button>)}</aside><section className="card settings-panel">{!settings&&<div className="profile-banner"><Avatar name="FM"/><div><div className="title">Fazeel Mahmood</div><span>BS Computer Science · Semester 4</span><Tag>ACTIVE STUDENT</Tag></div><Button variant="secondary" icon="edit">Edit profile</Button></div>}{tab==="Appearance"?<><div className="panel-title">Appearance</div><p>Choose how PTUT Hub looks across your devices.</p><div className="theme-options">{["Light","Dark","System"].map((x,i)=><button className={i===0?"active":""} key={x}><div className={`theme-preview theme-${x.toLowerCase()}`}><i/><span/><b/></div><span><i>{i===0&&<Icon name="check" size={14}/>}</i>{x}</span></button>)}</div><hr/><ToggleRow title="Reduce motion" text="Minimize interface animations and movement."/><ToggleRow title="Compact mode" text="Show more information with tighter spacing."/></>:settings?<><div className="panel-title">{tab}</div><p>Manage your {tab.toLowerCase()} preferences.</p><ToggleRow title="Class reminders" text="Notify me 15 minutes before every class."/><ToggleRow title="Exam reminders" text="Countdown alerts for upcoming assessments."/><ToggleRow title="Task deadlines" text="Remind me before work is due."/><ToggleRow title="PTUT announcements" text="Important updates from the university."/></>:<><div className="panel-title">Personal information</div><p>Your verified university details.</p><div className="profile-fields"><label>Full name<input value="Fazeel Mahmood" readOnly/></label><label>University email<input value="fazeel@ptut.edu.pk" readOnly/></label><label>Student ID<input value="PTUT-CS-2023-041" readOnly/></label><label>Phone<input value="+92 300 1234567" readOnly/></label></div><hr/><div className="academic-summary"><div><Icon name="building"/><span><small>DEPARTMENT</small>Computer Science</span></div><div><Icon name="book"/><span><small>PROGRAM</small>BS Computer Science</span></div><div><Icon name="people"/><span><small>ACADEMIC GROUP</small>Semester 4 · Section A</span></div></div></>}</section></div></div>;
}
function ToggleRow({title,text}:{title:string;text:string}){const [on,setOn]=useState(true);return <div className="toggle-row"><span><b>{title}</b><small>{text}</small></span><button className={on?"on":""} onClick={()=>setOn(!on)}><i/></button></div>}

function Admin({ screen }:{screen:Screen}) {
  if(screen==="manage-timetable") return <TimetableManager/>;
  if(screen==="manage-announcements") return <AnnouncementManager/>;
  if(screen==="students") return <ManagementTable title="Students" subtitle="2,842 enrolled students" cols={["STUDENT","ID","PROGRAM","SEMESTER","STATUS"]}/>;
  if(screen==="academic") return <ManagementTable title="Academic structure" subtitle="Departments, programs, semesters, and sections" cols={["PROGRAM","DEPARTMENT","SEMESTERS","SECTIONS","STATUS"]}/>;
  const stats=[["Total students","2,842","+8.4%","people"],["Active students","2,614","92%","user"],["Programs","18","6 departments","book"],["Upcoming exams","24","Next 30 days","exam"]];
  return <div className="page"><PageTitle eyebrow="ADMIN CONSOLE" title="Campus overview" text="Wednesday, 14 May 2025" action={<Button icon="plus">Create announcement</Button>}/><div className="admin-stats">{stats.map(x=><article className="card" key={x[0]}><div className="stat-icon"><Icon name={x[3] as IconName}/></div><span>{x[0]}</span><b>{x[1]}</b><small>{x[2]}</small></article>)}</div><div className="admin-grid"><section className="card analytics"><div className="card-heading"><div><b>Student activity</b><span>Weekly active users</span></div><select><option>Last 7 days</option></select></div><div className="bar-chart">{[42,58,49,72,84,61,77].map((x,i)=><div key={i}><i style={{height:`${x}%`}}/><span>{["Mon","Tue","Wed","Thu","Fri","Sat","Sun"][i]}</span></div>)}</div></section><section className="card"><div className="card-heading"><div><b>System status</b><span>Live overview</span></div><Tag>All systems normal</Tag></div><div className="system-list"><span><i className="green"/>Timetables<b>Published</b></span><span><i className="green"/>Announcements<b>12 active</b></span><span><i className="amber"/>Pending approvals<b>4 items</b></span><span><i className="green"/>Notification service<b>Operational</b></span></div></section></div><section className="card recent-table"><div className="card-heading"><div><b>Recent activity</b><span>Latest administrative changes</span></div><button>View audit log</button></div>{["Timetable published for BSCS Semester 4","New student accounts imported","Exam schedule updated","Announcement sent to all students"].map((x,i)=><div key={x}><span className="activity-avatar"><Icon name={i===1?"people":i===3?"bell":"calendar"}/></span><b>{x}<small>{["by Ahmad Khan · 12 minutes ago","284 records · 1 hour ago","by Dr. Ayesha · 3 hours ago","by Registrar Office · Yesterday"][i]}</small></b><Tag tone={i===2?"amber":"green"}>{i===2?"UPDATED":"COMPLETED"}</Tag></div>)}</section></div>;
}

function ManagementTable({title,subtitle,cols}:{title:string;subtitle:string;cols:string[]}) {
 const rows=title==="Students"?[["Areeba Hassan","PTUT-CS-23-018","BS Computer Science","4th · A","Active"],["Hamza Ahmed","PTUT-ET-22-104","Electrical Technology","6th · B","Active"],["Maham Riaz","PTUT-AE-24-044","Automotive Engineering","2nd · A","Active"],["Bilal Khan","PTUT-CS-23-062","BS Computer Science","4th · B","Inactive"]]:[["BS Computer Science","Computer Science","8","16","Active"],["BS Information Technology","Computer Science","8","8","Active"],["BSc Electrical Eng. Tech.","Electrical Engineering","8","12","Active"],["BSc Automotive Eng. Tech.","Automotive Engineering","8","8","Active"]];
 return <div className="page"><PageTitle eyebrow="MANAGEMENT" title={title} text={subtitle} action={<Button icon="plus">Add {title==="Students"?"student":"program"}</Button>}/><div className="management-tools"><div className="filter-search"><Icon name="search"/><input placeholder={`Search ${title.toLowerCase()}...`}/></div><Button variant="secondary">Filters</Button><Button variant="secondary">Export</Button></div><section className="card data-table"><div className="table-head">{cols.map(x=><span key={x}>{x}</span>)}<span/></div>{rows.map((r,i)=><div className="table-row" key={r[0]}>{r.map((x,j)=><span key={x}>{j===0?<><Avatar name={title==="Students"?x.split(" ").map(n=>n[0]).join(""):"BS"} small/><b>{x}</b></>:j===4?<Tag tone={x==="Inactive"?"gray":"green"}>{x}</Tag>:x}</span>)}<Button variant="icon" icon="more"/></div>)}</section><div className="pagination"><span>Showing 1–4 of {title==="Students"?"2,842":"18"}</span><div><Button variant="secondary">Previous</Button><Button variant="secondary">Next</Button></div></div></div>
}

function TimetableManager(){
 const [published,setPublished]=useState(false);
 return <div className="page"><PageTitle eyebrow="ADMIN · TIMETABLES" title="Timetable management" text="Build and publish schedules by academic group." action={<><Tag tone={published?"green":"amber"}>{published?"PUBLISHED":"DRAFT"}</Tag><Button onClick={()=>setPublished(true)}>Publish timetable</Button></>}/><section className="card selection-bar">{["Department","Program","Semester","Section"].map((x,i)=><label key={x}>{x}<select><option>{["Computer Science","BS Computer Science","Semester 4","Section A"][i]}</option></select></label>)}<Button icon="plus">Add entry</Button></section><div className="manager-layout"><section className="card compact-calendar"><div className="card-heading"><div><b>Weekly preview</b><span>Drag entries to adjust schedule</span></div><Button variant="secondary">Check conflicts</Button></div><div className="manager-days">{["Monday","Tuesday","Wednesday","Thursday","Friday"].map((d,i)=><div key={d}><b>{d}</b><button className={i%2?"blue":"green"}><span>{i%2?"Digital Logic":"Programming Fundamentals"}</span><small>{i%2?"09:00 – 10:30 · Rm 301":"10:00 – 11:30 · Lab 2"}</small></button><button className="purple"><span>Calculus</span><small>1:00 – 2:30 · Rm 101</small></button></div>)}</div></section><aside className="card edit-entry"><div className="card-heading"><div><b>Edit timetable entry</b><span>Wednesday · 10:00 AM</span></div><Button variant="icon" icon="close"/></div><label>Subject<select><option>Programming Fundamentals</option></select></label><label>Teacher<select><option>Dr. Ayesha Khan</option></select></label><label>Room<select><option>Computer Lab 2</option></select></label><div className="form-grid"><label>Start time<input type="time" value="10:00" readOnly/></label><label>End time<input type="time" value="11:30" readOnly/></label></div><Button className="full">Save changes</Button><Button variant="danger" icon="trash" className="full">Delete entry</Button></aside></div></div>
}

function AnnouncementManager(){
 return <div className="page"><PageTitle eyebrow="ADMIN · COMMUNICATIONS" title="Create announcement" text="Share timely updates with the right PTUT audience."/><div className="composer-layout"><section className="card composer"><label>Announcement title<input placeholder="Enter a clear, concise title"/></label><label>Description<textarea placeholder="Write your announcement..." rows={8}/></label><div className="form-grid"><label>Category<select><option>Important</option><option>University</option><option>Department</option></select></label><label>Audience<select><option>All students</option><option>Department</option><option>Section</option></select></label><label>Publish date<input type="date"/></label><label>Attachment<div className="file-input"><Icon name="plus"/>Add file</div></label></div><div className="modal-actions"><Button variant="secondary">Save draft</Button><Button>Review & publish</Button></div></section><aside className="card preview-panel"><div className="card-heading"><div><b>Live preview</b><span>Student view</span></div><Tag>PREVIEW</Tag></div><article className="announcement-card important"><Tag tone="red">IMPORTANT</Tag><div className="announcement-title">Your announcement title</div><b>PTUT Administration</b><p>Your announcement content will appear here as you type. Keep it clear and actionable.</p><span>Publishing today · All students</span></article></aside></div></div>
}

function CRDashboard(){
 return <div className="page"><PageTitle eyebrow="CLASS REPRESENTATIVE · SECTION A" title="Keep your section connected." text="Share verified updates and coordinate the academic day." action={<Button icon="plus">Post section update</Button>}/><div className="role-banner"><Icon name="shield"/><div><b>CR workspace</b><span>You can post to Section A, view engagement, and flag timetable changes. University-level controls remain restricted.</span></div><Tag>VERIFIED ROLE</Tag></div><div className="admin-stats">{[["Section students","42","40 active","people"],["Updates this month","12","86% read","bell"],["Classes this week","18","2 changes","calendar"],["Open questions","4","Needs reply","mail"]].map(x=><article className="card" key={x[0]}><div className="stat-icon"><Icon name={x[3] as IconName}/></div><span>{x[0]}</span><b>{x[1]}</b><small>{x[2]}</small></article>)}</div><div className="content-grid"><section className="card"><div className="card-heading"><div><b>Recent section updates</b><span>Visible to Semester 4 · Section A</span></div><button>View all</button></div>{["Data Structures makeup class confirmed","Programming lab groups updated","Calculus quiz moved to Monday"].map((x,i)=><div className="cr-update" key={x}><div className="float-icon"><Icon name={i===1?"people":"bell"}/></div><span><b>{x}</b><small>{[34,39,41][i]} of 42 students reached</small></span><Tag tone={i===0?"green":"gray"}>{i===0?"PINNED":"SENT"}</Tag></div>)}</section><aside className="card permission-card"><Icon name="shield" size={28}/><b>Your CR permissions</b><span><Icon name="check"/>Post section announcements</span><span><Icon name="check"/>Share timetable changes</span><span><Icon name="check"/>View section engagement</span><span className="muted"><Icon name="close"/>Edit official academic records</span></aside></div></div>
}

function StateGallery(){
 return <div className="page"><PageTitle eyebrow="SYSTEM STATES" title="Ready for every moment" text="Purposeful loading, empty, error, offline, and not-found experiences."/><div className="state-grid"><article className="card state-card"><div className="state-icon loading-icon"><span className="loader"/></div><b>Loading your dashboard</b><p>Getting today's classes and tasks ready...</p><div className="skeleton-lines"><i/><i/><i/></div></article><article className="card state-card"><div className="state-icon"><Icon name="check" size={28}/></div><b>No tasks yet</b><p>Capture your first task and make space for focused work.</p><Button icon="plus">Add first task</Button></article><article className="card state-card error-state"><div className="state-icon"><Icon name="alert" size={28}/></div><b>We couldn't load this page</b><p>Check your connection and try again. Your data is safe.</p><Button variant="secondary">Try again</Button></article><article className="card state-card offline-state"><div className="state-icon"><Icon name="wifi" size={28}/></div><b>You're offline</b><p>Your cached timetable and tasks are still available.</p><Tag tone="gray">LAST SYNCED 8 MIN AGO</Tag></article><article className="card state-card not-found"><strong>404</strong><b>This page skipped class</b><p>The page you're looking for doesn't exist or has moved.</p><Button>Back to dashboard</Button></article><article className="card state-card"><div className="state-icon"><Icon name="shield" size={28}/></div><b>Permission denied</b><p>This area is limited to PTUT administrators.</p><Button variant="secondary">Switch account</Button></article></div></div>
}

function Modal({title,children,onClose}:{title:string;children:React.ReactNode;onClose:()=>void}) {
 useEffect(()=>{const f=(e:KeyboardEvent)=>e.key==="Escape"&&onClose();addEventListener("keydown",f);return()=>removeEventListener("keydown",f)},[onClose]);
 return <div className="modal-backdrop" onMouseDown={onClose}><div className="modal" onMouseDown={e=>e.stopPropagation()}><div className="modal-head"><b>{title}</b><Button variant="icon" icon="close" onClick={onClose}/></div>{children}</div></div>
}

function SearchPalette({onClose}:{onClose:()=>void}){
 const [q,setQ]=useState("");
 const results=[["Subjects","Programming Fundamentals","Dr. Ayesha Khan · CS-204","book"],["Tasks","Programming assignment","Due tomorrow · 80% complete","check"],["Rooms","Computer Lab 2","Block A · Ground floor","room"],["Announcements","Lab schedule updated","Computer Science Department","bell"]];
 return <div className="modal-backdrop palette-backdrop" onMouseDown={onClose}><div className="palette" onMouseDown={e=>e.stopPropagation()}><div className="palette-input"><Icon name="search"/><input autoFocus placeholder="Search subjects, tasks, rooms, announcements..." value={q} onChange={e=>setQ(e.target.value)}/><kbd>ESC</kbd></div><div className="palette-body">{q&&<span className="result-count">Best matches for “{q}”</span>}{results.filter(x=>!q||x.join(" ").toLowerCase().includes(q.toLowerCase())).map(x=><button key={x[1]}><div className="result-icon"><Icon name={x[3] as IconName}/></div><span><small>{x[0]}</small><b>{x[1]}</b><i>{x[2]}</i></span><Icon name="arrow"/></button>)}</div><div className="palette-foot"><span><kbd>↑↓</kbd> Navigate</span><span><kbd>↵</kbd> Open</span><span><kbd>ESC</kbd> Close</span></div></div></div>
}

function NotificationDrawer({onClose}:{onClose:()=>void}){
 return <div className="drawer-backdrop" onMouseDown={onClose}><aside className="drawer" onMouseDown={e=>e.stopPropagation()}><div className="drawer-head"><div><b>Notifications</b><span>3 unread</span></div><Button variant="icon" icon="close" onClick={onClose}/></div><button className="mark-read">Mark all as read</button>{[["Class reminder","Digital Logic Design starts in 24 minutes.","calendar","Now"],["New announcement","Final examination form submission deadline.","bell","2h"],["Task due tomorrow","Programming assignment is 80% complete.","check","4h"],["System","Your profile information was updated.","settings","Yesterday"]].map((n,i)=><div className={`notification ${i<3?"unread":""}`} key={n[0]}><div className="result-icon"><Icon name={n[2] as IconName}/></div><div><b>{n[0]}</b><p>{n[1]}</p><span>{n[3]}</span></div>{i<3&&<i/>}</div>)}</aside></div>
}

function AppShell({onExit}:{onExit:()=>void}){
 const [screen,setScreen]=useState<Screen>("dashboard");
 const [role,setRole]=useState<"student"|"admin"|"cr">("student");
 const [search,setSearch]=useState(false);
 const [notify,setNotify]=useState(false);
 useEffect(()=>{const f=(e:KeyboardEvent)=>{if((e.metaKey||e.ctrlKey)&&e.key==="k"){e.preventDefault();setSearch(true)}};addEventListener("keydown",f);return()=>removeEventListener("keydown",f)},[]);
 const content=useMemo(()=>{
   if(role==="admin") return <Admin screen={screen}/>;
   if(role==="cr"&&screen==="cr") return <CRDashboard/>;
   if(screen==="dashboard") return <Dashboard setScreen={setScreen}/>;
   if(screen==="timetable") return <Timetable/>;
   if(screen==="tasks") return <Tasks/>;
   if(screen==="exams") return <Exams/>;
   if(screen==="announcements") return <Announcements/>;
   if(screen==="profile") return <ProfileSettings/>;
   if(screen==="settings") return <ProfileSettings settings/>;
   if(screen==="states") return <StateGallery/>;
   return <Dashboard setScreen={setScreen}/>;
 },[screen,role]);
 return <div className="app-shell"><Sidebar screen={screen} setScreen={setScreen} role={role} setRole={setRole}/><div className="app-main"><Header onSearch={()=>setSearch(true)} onNotify={()=>setNotify(true)}/>{content}</div><nav className="mobile-bottom">{navItems.slice(0,4).map(x=><button className={screen===x.id?"active":""} onClick={()=>setScreen(x.id)} key={x.id}><Icon name={x.icon}/><span>{x.label}</span></button>)}<button onClick={()=>setScreen("settings")}><Icon name="more"/><span>More</span></button></nav><button className="exit-demo" onClick={onExit}>Exit demo</button>{search&&<SearchPalette onClose={()=>setSearch(false)}/>} {notify&&<NotificationDrawer onClose={()=>setNotify(false)}/>}</div>
}

export default function App() {
  const [flow,setFlow]=useState<"landing"|"auth"|"onboarding"|"app">("landing");
  if(flow==="landing") return <Landing onStart={()=>setFlow("auth")}/>;
  if(flow==="auth") return <Auth onBack={()=>setFlow("landing")} onComplete={()=>setFlow("onboarding")}/>;
  if(flow==="onboarding") return <Onboarding onComplete={()=>setFlow("app")}/>;
  return <AppShell onExit={()=>setFlow("landing")}/>;
}
